// This file is used to build the pre-compiled header on those
// systems that support it.

#include "splib.h"

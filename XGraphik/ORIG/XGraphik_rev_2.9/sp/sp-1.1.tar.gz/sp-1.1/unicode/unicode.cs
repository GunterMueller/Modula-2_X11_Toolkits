-- Definition of Unicode --
0 65536 0

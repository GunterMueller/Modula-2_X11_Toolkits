#include <stdio.h>
#include "FontsInterna.h"

void main (void) {
  int i, j;
  unsigned char c;

  initFonts();


  outputFont (eFontHelvetica, eStyleNormal);

}
